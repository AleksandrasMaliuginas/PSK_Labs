create unique index PRIMARY_KEY_BB
    on SUBJECT (ID);

